/*
 * @Author: gangzhigm 864853934@qq.com
 * @Date: 2022-12-28 09:45:49
 * @LastEditors: gangzhigm 864853934@qq.com
 * @LastEditTime: 2023-01-09 16:51:37
 * @FilePath: \playa\front\src\components\utils.ts
 * @Description: 实现方法组
 */
import * as THREE from "three"
import * as INTERFACE_D from "../dts/interface_d";
import * as TYPE_D from "../dts/type_d";
  
const random_noise_1:INTERFACE_D.random_noise_1 = function (noise_size=2){
  let list:[number,number][] = [];
  for(let i = 0; i < noise_size; i+=1){
      list.push([Number(Math.random().toFixed(2)),i])
  }
  return list
}

const sin_random_noise_1 = function (noise_size=[2,6], Op){
  
  let list:[number,number][] = [];
  for(let i = 0; i < (noise_size[1] - noise_size[0]); i+=1){
    const value = isNaN(Number(`0.${(Math.sin(i+noise_size[0]) * Number(Op)).toString().split(".")[1]}`)) ? 0 : Number(`0.${(Math.sin(i+noise_size[0]) * Number(Op)).toString().split(".")[1]}`);
    list.push([value,i])
  }
  return list
}

const value_noise_1:INTERFACE_D.value_noise_1 = function (
  noise_size=100, 
  anchorPoint_count=2, 
  start_end_default_value=[0,0], 
  equalization_mode=0, 
  border_override_mode=1
){
  anchorPoint_count = border_override_mode === 0 ? anchorPoint_count + 2 : anchorPoint_count;  

  if( noise_size <  anchorPoint_count ) {
    throw new Error("锚点量超过生成长度")
  }
  

  let anchorPoint_list:Set<number> = new Set();
  
  if(equalization_mode === 0){
    for(let i = 0; i < anchorPoint_count; i+=1){
      let index = Math.floor(Math.random() * noise_size); 
      do {
        if(!anchorPoint_list.has(index)){
          anchorPoint_list.add(index)
          break;
        }
        else{
          index = Math.floor(Math.random() * noise_size); 
        }
      } while(true);
    }
  }
  else if(anchorPoint_count === 1){
    anchorPoint_list.add(noise_size / 2 - 1)
  }
  else{
    anchorPoint_list = get_average_1(noise_size, anchorPoint_count)
    anchorPoint_list.delete(noise_size);
    anchorPoint_list.add(noise_size - 1);
  }

  if(border_override_mode === 0){
    anchorPoint_list.delete(0);
    anchorPoint_list.delete(noise_size - 1);
  }

  let list = new Array(noise_size);

  list[0] = [start_end_default_value[0],0];
  list[list.length - 1] = [start_end_default_value[1],list.length - 1];

  anchorPoint_list.forEach(index=>{
    list[index] = [Math.random().toFixed(2),index,1]
  })

  for(let i = 0; i < noise_size; i++){
    if(list[i] === void 0){
      const start = list.filter((item, index)=>index < i).reverse()[0];
      const end = list.filter((item, index)=>index > i)[0];
      const interpolation = Number(((i - start[1]) / (end[1] - start[1])).toFixed(2));
      list[i] = [lerp(start[0], end[0], interpolation),i,0]
    }
  }
  return list;
}

export { 
  value_noise_1,
  random_noise_1,
  sin_random_noise_1,
}



