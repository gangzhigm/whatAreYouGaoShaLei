/*
 * @Author: gangzhigm 864853934@qq.com
 * @Date: 2022-12-28 09:45:49
 * @LastEditors: gangzhigm 864853934@qq.com
 * @LastEditTime: 2023-01-09 16:54:47
 * @FilePath: \playa\front\src\components\utils.ts
 * @Description: 实现方法组
 */
import * as THREE from "three"
import * as INTERFACE_D from "../dts/interface_d";
import * as TYPE_D from "../dts/type_d";
  
const createFloor_1:INTERFACE_D.createFloor_1 = function (floor_Scale=[1,2], floor_size=[1,1,1]){
  const floor_1_group = new THREE.Group();
  const list_1:TYPE_D.Render_Item_1[] = [
    // 1维 value_noise_不均衡_不覆盖
    [floor_size,value_noise_1(40,10,[.4,.4], 0, 0), floor_1_group,floor_Scale,0,0],
    // 1维 value_noise_不均衡_覆盖
    [floor_size,value_noise_1(40,10,[.4,.4], 0, 1),floor_1_group,floor_Scale,10, 60],
    // 1维 value_noise_均衡_不覆盖
    [floor_size,value_noise_1(40,10,[.4,.4], 1, 0),floor_1_group,floor_Scale,20, 120],
    // 1维 value_noise_均衡_覆盖
    [floor_size,value_noise_1(40,10,[.4,.4], 1, 1),floor_1_group,floor_Scale,30, 180],
    // 1维 value_noise_全随机算法
    [floor_size,value_noise_1(40,40),floor_1_group,floor_Scale,40],
    // 1维 全随机算法
    [floor_size,random_noise_1(40),floor_1_group,floor_Scale,50],
    // 1维 正弦随机算法
    [floor_size,sin_random_noise_1([0,100], 100000),floor_1_group,floor_Scale,60],
  ]
  list_1.forEach(item=>{
    render_1_block(item)
  })
  const thing_1 = box_center_world(floor_1_group);
  return thing_1;
}

const createFloor_2:INTERFACE_D.createFloor_2 = function (floor_Scale=[1,2], floor_size=[1,1,1]){
  const floor_2_group = new THREE.Group();
  const list_2:TYPE_D.Render_Item_2[] = [
    // 2维 全随机算法
    [ floor_size, random_noise_2([20,20]), floor_2_group, floor_Scale, 0],
    // // 2维 y=6x^5-15x^4+10x^3_插值_单边计算
    [ floor_size, value_noise_2([4,4], 20, "b"), floor_2_group, floor_Scale, 30],
    // // 2维 value_noise算法_线性插值
    [ floor_size, value_noise_2([16,16], 20, "a"), floor_2_group, floor_Scale, 60],
    // // 2维 value_noise算法_y=6x^5-15x^4+10x^3_插值
    [ floor_size, value_noise_2([16,16], 20, "c"), floor_2_group, floor_Scale, 90],
  ]
  list_2.forEach(item=>{
    render_2_block(item);
  })
  const thing_2 = box_center_world(floor_2_group);
  return thing_2;
}

const createFloor_3:INTERFACE_D.createFloor_2 = function (floor_Scale=[1,2], floor_size=[1,1,1]){
  const floor_3_group = new THREE.Group();
  const list_3:TYPE_D.Render_Item_2[] = [
    // 3维 全随机算法
    // [ floor_size, random_noise_3([20,20,20]), floor_3_group, floor_Scale, 0],
    // 3维 非全随机算法
    [ floor_size, value_noise_3(), floor_3_group, floor_Scale, 40],
  ]
  list_3.forEach(item=>{
    render_3_block(item);
  })
  const thing_3 = box_center_world(floor_3_group);
  return thing_3;
}

const render_1_block:INTERFACE_D.render_1_block_fn = function ([
  unit_size=[1,1,1],
  list=[],
  group,
  unit_scale=[1,2],
  offset=0,
  anchorPointColor=0,
  axis="x"
]:TYPE_D.Render_Item_1){
  const axis_list = ["x", "z"]
  const axis_index = axis_list.findIndex(item=>item===axis);
  const position_value:[number,number,number] = [offset,offset,offset]
  const geometry = new THREE.BoxGeometry( ...unit_size );
  list.forEach(item=>{
    let coefficient = item[0]
    const scale_Coefficient = Number((coefficient * (unit_scale[1] - unit_scale[0]) + unit_scale[0]).toFixed(1));
    const y_axis = unit_size[1]*scale_Coefficient / 2;
    const color = item[2] === 1 ? new THREE.Color(`hsl(${anchorPointColor}, 100%, 50%)`) : new THREE.Color(`hsl(0, 0%, ${item[0]*100}%)`);
    const material = new THREE.MeshStandardMaterial({color});
    const cube = new THREE.Mesh( geometry, material );
    cube.scale.y = scale_Coefficient;
    
    position_value[1]= y_axis;
    position_value[axis_index]= item[1];
    
    cube.position.set(...position_value);

    group.add(cube);
  })
}

const render_2_block:INTERFACE_D.render_2_line_fn = function ([
  unit_size=[1,1,1],
  list=[],
  group,
  unit_scale=[1,2],
  offset=0,
]:TYPE_D.Render_Item_2){
  let position_value:[number,number,number] = [0,0,0]
  const geometry = new THREE.BoxGeometry( ...unit_size );
  list.forEach(item=>{

    let coefficient = item[0]
    const scale_Coefficient = Number((coefficient * (unit_scale[1] - unit_scale[0]) + unit_scale[0]).toFixed(1));
    
    const y_axis = unit_size[1]*scale_Coefficient / 2;

    let color = item[3] === 1 ? 
      new THREE.Color(`hsl(0, 0%, ${item[0]*100}%)`) :
      new THREE.Color(`hsl(0, 0%, ${item[0]*100}%)`);
    const material = new THREE.MeshStandardMaterial({color});
    const cube = new THREE.Mesh( geometry, material );

    cube.scale.y = scale_Coefficient;
    position_value[0] = item[1];
    position_value[1]= y_axis;
    position_value[2] = item[2] + offset;
    cube.position.set(...position_value);
    
    group.add(cube);
  })
}

const render_3_block = function ([
  unit_size=[1,1,1],
  list=[],
  group,
  unit_scale=[1,2],
  offset=0,
]){
    const geometry = new THREE.BoxGeometry( ...unit_size );
    list.forEach(item=>{
      let color = item[4] === 1 ? 
        new THREE.Color(`hsl(0, 0%, ${item[0]*100}%)`) :
        new THREE.Color(`hsl(0, 0%, ${item[0]*100}%)`);
      let coefficient = item[0]
      const scale_Coefficient = Number((coefficient * (unit_scale[1] - unit_scale[0]) + unit_scale[0]).toFixed(1));

      const material = new THREE.MeshStandardMaterial({color});
      const cube = new THREE.Mesh( geometry, material );

      cube.scale.set(scale_Coefficient,scale_Coefficient,scale_Coefficient);

      const x_axis = item[1];
      // const x_axis = item[1] * (1-scale_Coefficient) * 3;

      const y_axis = item[2] + unit_size[1] / 2;
      // const y_axis = item[2] * scale_Coefficient * 3 + unit_size[1] / 2;
      
      const z_axis = item[3] + offset;
      // const z_axis = item[3] * scale_Coefficient * 3 + offset;

      cube.position.set(x_axis,y_axis,z_axis)
      group.add(cube);

    })
}











export { 
  
  render_1_block,
  render_2_block,
  render_3_block,
  
  createFloor_1,
  createFloor_2,
  createFloor_3,
  
}