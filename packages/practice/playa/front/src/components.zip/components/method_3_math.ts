/*
 * @Author: gangzhigm 864853934@qq.com
 * @Date: 2022-12-28 09:45:49
 * @LastEditors: gangzhigm 864853934@qq.com
 * @LastEditTime: 2023-01-09 16:51:30
 * @FilePath: \playa\front\src\components\utils.ts
 * @Description: 实现方法组
 */
import * as THREE from "three"
import * as INTERFACE_D from "../dts/interface_d";
import * as TYPE_D from "../dts/type_d";
  
const random_noise_3:INTERFACE_D.random_noise_3 = function (noise_size=[2,2,2]){
    let list:[number, number, number, number][] = [];
    for(let i = 0; i < noise_size[0]; i+=1){
      for(let j = 0; j < noise_size[1]; j+=1){
        for(let z = 0; z < noise_size[2]; z+=1){
            list.push([Number(Math.random().toFixed(2)),i,j,z])
        }
      }
    }
    return list
}

const value_noise_3 = function (anchorPoint_count=[2,2,2], sizeingss = 10){

  let number = {
    x:10,
    y:10,
    z:10
  };
  number.x += 1; 
  number.y += 1; 
  number.z += 1; 

  let list:any[] = []
  for(let x = 0; x <= number.x; x++){
    for(let y = 0; y <= number.y; y++){
      for(let z = 0; z <= number.z; z++){
        list.push(
          {
            x,
            y,
            z,
            v:0
          }
        )
      }
    }
  }

  function checkAnchorPoint_3(list:any){
    const returnList:any = [[],[]]
    list.forEach((item:any)=>{
      const {x,y,z,v}:any = {...item}
      if((
        (x === 0 && y === 0 && z === 0) ||
    
        (x === number.x && y === 0 && z === 0) ||
        (x === 0 && y === number.y && z === 0) ||
        (x === 0 && y === 0 && z === number.z) ||
    
        (x === 0 && y === number.y && z === number.z) ||
        (x === number.x && y === 0 && z === number.z) ||
        (x === number.x && y === number.y && z === 0) ||
    
        (x === number.x && y === number.y && z === number.z)
      )){
        returnList[0].push(item)
      }
      else{
        returnList[1].push(item)
      }
    })
    return returnList;
  }
  

  const [anchorPoint_list, normal_list] = [...checkAnchorPoint_3(list)];


  anchorPoint_list.forEach((item:any)=>{
    item.v = Math.random();
  })

  
  
  
  const anchorPoint_Zone_list = {
    without_X:[
      anchorPoint_list.filter(({x}:any)=>x === 0),
      anchorPoint_list.filter(({x}:any)=>x === number.x)
    ],
    without_Y:[
      anchorPoint_list.filter(({y}:any)=>y === 0),
      anchorPoint_list.filter(({y}:any)=>y === number.y)
    ],
    without_Z:[
      anchorPoint_list.filter(({z}:any)=>z === 0),
      anchorPoint_list.filter(({z}:any)=>z === number.z)
    ]
  }
  
const cawd = normal_list.map(dot_item=>{

    const a = Object.keys(anchorPoint_Zone_list).map(name=>{
      let Zone = [];
      const Faces =  anchorPoint_Zone_list[name].map(item=>{

        Zone = [];

        if(name === "without_X"){
          Zone.push("y","z","x");
        }
        if(name === "without_Y"){
          Zone.push("x","z","y");
        }
        if(name === "without_Z"){
          Zone.push("x","y","z");
        }

        // 维度1总长度
        const one_H = number[Zone[0]];
        // 维度1起始点到点长度
        const one_HN = dot_item[Zone[0]];
        // 维度1起始点到点比例，用于结束端长度常数
        const one_EO = one_HN === 0 || one_H === 0 ? 0 : Number((one_HN / one_H).toFixed(2));
        // 维度1结束点到点比例，用于起始端长度常数
        const one_SO = 1 - one_EO;


        // 维度2总长度
        const two_H = number[Zone[1]];
        // 维度2起始点到点长度
        const two_HN = dot_item[Zone[1]];
        // 维度2起始点到点比例，用于结束端长度常数
        const two_EO = two_HN === 0 || two_H === 0 ? 0 : Number((two_HN / two_H).toFixed(2));
        // 维度2结束点到点比例，用于起始端长度常数
        const two_SO = 1 - two_EO;
        
        // 上左数值
        const TLV = item[0].v;
        // 上右数值
        const TRV = item[1].v;
        // 下左数值
        const BLV = item[2].v;
        // 下右数值
        const BRV = item[3].v;

        // A_总数值
        
        return  ( TLV * one_SO + TRV * one_EO ) * two_SO + ( BLV * one_SO + BRV * one_EO ) * two_EO;

      })

    // 维度3总长度
    const thr_H = number[Zone[2]];
    // 维度3起始点到点长度
    const thr_HN = dot_item[Zone[2]];
    // 维度3起始点到点比例，用于结束端长度常数
    const thr_EO = thr_HN === 0 || thr_H === 0 ? 0 : Number((thr_HN / thr_H).toFixed(2));
    // 维度3结束点到点比例，用于起始端长度常数
    const thr_SO = 1 - thr_EO;

    return Faces[0] * thr_SO + Faces[1] * thr_EO
  })

  // console.info(a);
  return Object.assign(dot_item, {v:a[2]})
  return Object.assign(dot_item, {v:a[0] + a[1] + a[2]})

})

// console.info(cawd);
  
  
  

  

  
  list = list.map(({x,y,z,v})=>[v,x,y,z]);

  return list



}

export { 
  random_noise_3,
  value_noise_3
}