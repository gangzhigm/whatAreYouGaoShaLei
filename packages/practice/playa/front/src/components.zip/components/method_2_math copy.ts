/*
 * @Author: gangzhigm 864853934@qq.com
 * @Date: 2022-12-28 09:45:49
 * @LastEditors: gangzhigm 864853934@qq.com
 * @LastEditTime: 2023-01-10 10:22:20
 * @FilePath: \playa\front\src\components\utils.ts
 * @Description: 实现方法组
 */
import * as THREE from "three"

import * as TYPE_D from "../dts/type_d";
import * as INTERFACE_D from "../dts/interface_d";

import * as Lib from "./method_lib";

  
const random_noise_2:INTERFACE_D.random_noise_2 = function (noise_size=[2,2]){
    let list:[number,number,number][] = [];
    for(let i = 0; i < noise_size[0]; i+=1){
      for(let j = 0; j < noise_size[1]; j+=1){
          list.push([Number(Math.random().toFixed(2)),i,j])
      }
    }
    return list
}

const value_noise_2:INTERFACE_D.value_noise_2 = function (anchorPoint_count=[3,3], sizeingss = 10, type="a"){

  // 单个块尺寸
  let itemSize = Math.ceil(sizeingss / anchorPoint_count[0]);
  
  // 添加锚点行列
  itemSize += 2;
  
  // 返回列表参数
  let list:[number,number,number,number][][] = [];
  
  // 噪音图渲染尺寸
  let mapsize = anchorPoint_count.map(item => item * (itemSize - 2));
  

  // 添加边界值处理锚点,即若传入1，1即分块横1竖1，即锚点行列为横2竖2，即n分块n+1锚点行列
  anchorPoint_count = [
    anchorPoint_count[0] + 1,
    anchorPoint_count[1] + 1
  ];

  
  
  
  // 添加锚点信息以及分配参数
  const anchorPoint_list: TYPE_D.Number_Array_3[] = [];
  const anchorPoint_list_x = Lib.get_average_1(mapsize[0], anchorPoint_count[0])
  const anchorPoint_list_y = Lib.get_average_1(mapsize[1], anchorPoint_count[1])
  anchorPoint_list_x.forEach(itemI=>{
    anchorPoint_list_y.forEach(itemJ=>{
      anchorPoint_list.push([itemI,itemJ,Number(Math.random().toFixed(2))]);
    })
  })





  let block:number[][][] = [];
  anchorPoint_list.forEach(data => {
    const Y = Lib.get_near_2(anchorPoint_list
      .filter(item => item[0] > data[0] && item[1] === data[1]), [data[0],data[1]])
    const X = Lib.get_near_2(anchorPoint_list
      .filter(item => item[0] === data[0] && item[1] > data[1]), [data[0],data[1]])
    const XY = Lib.get_near_2(anchorPoint_list
      .filter(item => item[0] > data[0] && item[1] > data[1]), [data[0],data[1]])
    if(X !== null && Y !== null && XY !== null){
      block.push([ data, X, Y, XY ]) 
    }
  })
  


  // 遍历块参数，生成块图
  block.forEach((blockItem)=>{
    // 定义块锚点参数
    const anchorPoint_data_list:[number,number,number,number][]= [];
    const anchorPoint_list = [
      [0,0],
      [0,itemSize - 1],
      [itemSize - 1,0],
      [itemSize - 1, itemSize - 1]
    ]


    anchorPoint_list.forEach((anchorPoint, index)=>{
      anchorPoint_data_list.push([blockItem[index][2],anchorPoint[0],anchorPoint[1],1]);
    })
  

    // 根据块锚点参数生成块内点参数
    let block_in_list:[number,number,number,number][] = [];
    for(let i = 0; i < itemSize; i++){
      for(let j = 0; j < itemSize; j++){
        const anchorPoint = anchorPoint_data_list.find(item=>item[1] === i && item[2] === j)

        if(anchorPoint){
          block_in_list[Lib.get_index_2_to_1([itemSize,itemSize], [i,j])] = anchorPoint;
        }
        else{ 
          // 左上
          const TL = Lib.get_near_2(anchorPoint_data_list.filter(item => item[1] <= i && item[2] <= j), [i,j])//.map((item,index)=>index === 1 || index === 2 ? item + 1 : item);
          // 左下
          const BL = Lib.get_near_2(anchorPoint_data_list.filter(item => item[1] <= i && item[2] >= j), [i,j])//.map((item,index)=>index === 1 || index === 2 ? item + 1 : item);
          // 右上
          const TR = Lib.get_near_2(anchorPoint_data_list.filter(item => item[1] >= i && item[2] <= j), [i,j])//.map((item,index)=>index === 1 || index === 2 ? item + 1 : item);
          // 右下
          const BR = Lib.get_near_2(anchorPoint_data_list.filter(item => item[1] >= i && item[2] >= j), [i,j])//.map((item,index)=>index === 1 || index === 2 ? item + 1 : item);
          
          if(TL === null || BL === null || TR === null || BR === null){
            throw("当前锚点或为0!");
          }

          // 上总长度
          const TH = TR[1] - TL[1];
          // 上左到点长度
          const THN = i - TL[1];
          // 上左到点比例
          const TRO = THN === 0 || TH === 0 ? 0 : Number((THN / TH).toFixed(2));
          // 上右到点比例
          const TLO = 1 - TRO;

          // 下总长度
          const BH = BR[1] - BL[1];
          // 下左到点长度
          const BHN = i - BL[1];
          // 下左到点比例
          const BRO = BHN === 0 || BH === 0 ? 0 : Number((BHN / BH).toFixed(2));
          // 下右到点比例
          const BLO = 1 - BRO;

          // 竖总长度
          const CH = BL[2] - TL[2];
          // 竖上到点长度
          const CHN = j - TL[2];
          // 竖上到点比例
          const CBO = CHN === 0 || CH === 0 ? 0 : Number((CHN / CH).toFixed(2));
          // 竖下到点比例
          const CTO = 1 - CBO;

          // 上左数值
          const TLV = TL[0];
          // 上右数值
          const TRV = TR[0];
          // 下左数值
          const BLV = BL[0];
          // 下右数值
          const BRV = BR[0];
          
          // A_竖总数值
          const a_value = ( TLV * TLO + TRV * TRO ) * CTO + ( BLV * BLO + BRV * BRO ) * CBO
        
          
          // 上左到点比例
          const TESTTLO = TRO;
          // 上左数值
          const TESTTLV = TLV;
          // 上右数值
          const TESTTRV = TRV;
          // 上总数值
          const TVALUE = Number((Lib.lerp_2(TESTTLO) * (TESTTRV - TESTTLV)).toFixed(2));

          // 下左到点比例
          const TESTBLO = BRO;
          // 下左数值
          const TESTBLV = BLV;
          // 下右数值
          const TESTBRV = BRV;
          // 下总数值
          const BVALUE = Number((Lib.lerp_2(TESTBLO) * (TESTBRV - TESTBLV)).toFixed(2));

          // 竖上到点比例
          const TESTCLO = CBO;
          // 竖上数值
          const TESTCLV = TVALUE;
          // 竖下数值
          const TESTCRV = BVALUE;
          // B_竖总数值
          const b_value = Number((Lib.lerp_2(TESTCLO) * (TESTCRV - TESTCLV)).toFixed(2));


          // 上左到点比例
          const TESTB_TLO = TRO;
          // 上左数值
          const TESTB_TLV = TLV;
          // 上右数值
          const TESTB_TRV = TRV;
          
          const TESTB_A = Lib.lerp_2(TESTB_TLO);
          const TESTB_B = Number((1 - Lib.lerp_2(TESTB_TLO)).toFixed(2));


          // 下左到点比例
          const TESTB_BLO = BRO;
          // 下左数值
          const TESTB_BLV = BLV;
          // 下右数值
          const TESTB_BRV = BRV;
          
          const TESTB_C = Lib.lerp_2(TESTB_BLO);
          const TESTB_D = Number((1 - Lib.lerp_2(TESTB_BLO)).toFixed(2));


          // 竖上到点比例
          const TESTB_CTO = CBO;
          const TESTB_CTV = Number((TLV * TESTB_B + TRV * TESTB_A).toFixed(2)) 
          const TESTB_CBV = Number((BLV * TESTB_D + BRV * TESTB_C ).toFixed(2))

          const TESTB_E = Lib.lerp_2(TESTB_CTO);
          const TESTB_F = Number((1 - Lib.lerp_2(TESTB_CTO)).toFixed(2));

          // C_竖总数值
          const c_value = Number((TESTB_CTV * TESTB_F + TESTB_CBV * TESTB_E).toFixed(2));


          let itemValue = 0;
          if(type === "a"){
            itemValue = Number(Math.abs(a_value))
          }
          else if(type === "b"){
            itemValue = Number(Math.abs(b_value))
          }
          else if(type === "c"){
            itemValue = Number(Math.abs(c_value))
          }


          block_in_list[Lib.get_index_2_to_1([itemSize, itemSize], [i,j])] = [itemValue,i,j,0];

        }
      }
    }

    // 清洗块参数
    block_in_list = block_in_list.filter(item => anchorPoint_data_list.findIndex(it=>it[1] === item[1] || it[2] === item[2]) < 0)
    
    
    block_in_list = block_in_list.map(item=>[item[0],item[1] - 1,item[2] - 1,item[3]])
    
    // 修正点索引值
    block_in_list = block_in_list.map(item=>[item[0],item[1] + blockItem[0][0],item[2] + blockItem[0][1],item[3]])
    
    
    list.push(block_in_list);
  })
  // 清洗整体参数
  let finish_list:[number,number,number,number][] = list.flat(1);

  finish_list = finish_list.filter((item: number[]) => item[1] < sizeingss && item[2] < sizeingss)

  return finish_list;


}

export { 
  value_noise_2,
  random_noise_2
}