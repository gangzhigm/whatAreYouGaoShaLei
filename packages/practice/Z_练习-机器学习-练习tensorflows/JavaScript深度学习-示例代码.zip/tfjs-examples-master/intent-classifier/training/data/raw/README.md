# Data Source

Data is sourced from https://github.com/snipsco/nlu-benchmark

A. Coucke et al., “Snips Voice Platform: an embedded Spoken Language Understanding system for private-by-design voice interfaces,” arXiv:1805.10190 [cs], May 2018.
